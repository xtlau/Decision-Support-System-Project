# MIE 451/1513 Assignment: information retrieval
We will go through the tutorial notebook during the lab this week: [IR_Lab.ipynb](IR_Lab.ipynb)

For this assignment, please:

- Read the instruction PDF: [MIE_1513_Decision_Support_Systems_Assignment__Information_Retrieval__IR_.pdf](MIE_1513_Decision_Support_Systems_Assignment__Information_Retrieval__IR_.pdf)

- Complete and upload the assignment notebook: [ir_assignment.ipynb](ir_assignment.ipynb)
